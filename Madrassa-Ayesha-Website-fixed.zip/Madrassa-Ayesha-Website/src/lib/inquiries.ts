export interface Inquiry { kind: "admission" | "contact"; name: string; phone?: string; program?: string; message?: string }
/**
 * Firebase-ready hook. Returns true only when the inquiry was really stored.
 * To enable: `npm i firebase`, create src/lib/firebase.ts with initializeApp(...) using VITE_FIREBASE_* vars,
 * then replace the body with: await addDoc(collection(db, "inquiries"), { ...data, createdAt: serverTimestamp() }); return true;
 */
export async function submitInquiry(_data: Inquiry): Promise<boolean> {
  return false; // no backend configured yet, so the UI never claims success
}
