import { ReactNode, useEffect, useRef, useState } from "react";

export function Reveal({ children, className = "", label }: { children: ReactNode; className?: string; label?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); io.disconnect(); } }, { threshold: 0.12 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <div ref={ref} className={`rv ${on ? "in" : ""} ${className}`} role={label ? "img" : undefined} aria-label={label}>{children}</div>;
}

export function Note({ children }: { children: ReactNode }) { return <span className="note">{children}</span>; }

export function Heading({ eyebrow, title, note }: { eyebrow: string; title: string; note?: string }) {
  return <Reveal><div className="eyebrow">{eyebrow}</div><h2>{title}</h2>{note && <Note>{note}</Note>}</Reveal>;
}

export function InfoCard({ icon, title, text }: { icon: ReactNode; title: string; text: string }) {
  return <Reveal className="card"><div className="ic">{icon}</div><h3>{title}</h3><p>{text}</p></Reveal>;
}

const COLS: [string, string][] = [["#064E3B", "#C9A24A"], ["#023B2E", "#e8d9a8"], ["#0b6b50", "#FAF8F1"], ["#C9A24A", "#023B2E"], ["#064E3B", "#FAF8F1"], ["#023B2E", "#C9A24A"]];
export function GalleryArt({ i }: { i: number }) {
  const [bg, fg] = COLS[i % COLS.length];
  return (
    <svg viewBox="0 0 200 200" aria-hidden="true">
      <rect width="200" height="200" fill={bg} />
      <g fill="none" stroke={fg} strokeWidth="2">
        <path d="M40 200V100C40 55 100 25 100 25s60 30 60 75v100" /><path d="M62 200V105c0-30 38-48 38-48s38 18 38 48v95" />
        <path d="M100 90l8 18 18 8-18 8-8 18-8-18-18-8 18-8z" />
      </g>
    </svg>
  );
}

export function Logo({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke="#C9A24A" strokeWidth="2" aria-hidden="true">
      <path d="M6 44V22C6 10 24 2 24 2s18 8 18 20v22z" /><path d="M12 44V23c0-8 12-14 12-14s12 6 12 14v21" opacity=".6" />
      <path d="M24 40c-4-3-9-3-12-2V26c3-1 8-1 12 2 4-3 9-3 12-2v12c-3-1-8-1-12 2zM24 28v12" />
    </svg>
  );
}
