// PLACEHOLDER: set VITE_WHATSAPP_NUMBER (digits only, with country code) in .env / Vercel settings.
export const WA_NUMBER: string = import.meta.env.VITE_WHATSAPP_NUMBER ?? "923000000000";
export const WA_URL = `https://wa.me/${WA_NUMBER}`;
