import { FormEvent, useEffect, useState } from "react";
import { BookOpen, GraduationCap, Landmark, Languages, Library, Menu, MessageCircle, MoonStar, Mic, PenLine, Scale, School, Sparkles, Sprout, X } from "lucide-react";
import { Dict, Lang, PROGRAMS_EN, T } from "./i18n";
import { WA_URL } from "./config";
import { submitInquiry } from "./lib/inquiries";
import { GalleryArt, Heading, InfoCard, Logo, Note, Reveal } from "./components/ui";

const PROGRAM_ICONS = [BookOpen, Landmark, Sparkles, Mic, Library, MoonStar, Languages, PenLine];
const FEATURE_ICONS = [Landmark, GraduationCap, BookOpen, Sprout, Scale, School];
const NAV: [string, string][] = [["about", "n_about"], ["programs", "n_prog"], ["why", "n_why"], ["gallery", "n_gal"], ["admissions", "n_adm"], ["contact", "n_con"]];
const PHONE_OK = /^\d{10,14}$/;

function Navbar({ t, lang, setLang }: { t: Dict; lang: Lang; setLang: (l: Lang) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 40);
    f(); window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <nav className={scrolled ? "s" : ""} aria-label="Main">
      <div className="wrap">
        <a className="brand" href="#home"><Logo /><span className="serif" style={{ fontSize: 19 }}>{t.short}</span></a>
        <div className={`links ${open ? "open" : ""}`} onClick={() => setOpen(false)}>
          {NAV.map(([id, k]) => <a key={id} href={`#${id}`}>{t[k]}</a>)}
          <div className="lang" role="group" aria-label="Language" onClick={(e) => e.stopPropagation()}>
            {(["en", "ur", "ar"] as Lang[]).map((l) => (
              <button key={l} className={lang === l ? "on" : ""} aria-pressed={lang === l} onClick={() => setLang(l)}>{l === "en" ? "EN" : l === "ur" ? "اردو" : "عربي"}</button>
            ))}
          </div>
        </div>
        <button id="burger" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X size={20} /> : <Menu size={20} />}</button>
      </div>
    </nav>
  );
}

function Hero({ t }: { t: Dict }) {
  return (
    <header className="hero" id="home">
      <svg className="pat" aria-hidden="true"><defs><pattern id="p" width="80" height="80" patternUnits="userSpaceOnUse"><path d="M40 6l10 24 24 10-24 10-10 24-10-24L6 40l24-10z" fill="none" stroke="#C9A24A" strokeWidth="1" /></pattern></defs><rect width="100%" height="100%" fill="url(#p)" /></svg>
      <svg className="arch" viewBox="0 0 400 300" fill="none" stroke="#C9A24A" strokeWidth="2" aria-hidden="true"><path d="M20 300V130C20 50 200 5 200 5s180 45 180 125v170M60 300V135c0-60 140-95 140-95s140 35 140 95v165M100 300V145c0-40 100-65 100-65s100 25 100 65v155" /></svg>
      <div className="wrap">
        <div className="ar rise">مدرسة عائشة صديقة للبنات كاتلنج</div>
        <div className="serif rise d1" style={{ fontSize: 20, letterSpacing: ".06em" }}>Madrassa Aysha Siddiqa Lilbanat Katlang</div>
        <h1 className="rise d1">{t.h1}</h1><p className="rise d2">{t.hp}</p>
        <div className="btns rise d3"><a className="btn b1" href="#about">{t.b1}</a><a className="btn b2" href="#admissions">{t.b2}</a></div>
      </div>
    </header>
  );
}

function About({ t }: { t: Dict }) {
  return (
    <section id="about"><div className="wrap grid g2">
      <Reveal><div className="eyebrow">{t.n_about}</div><h2>{t.a_h}</h2><p>{t.a_p}</p><br />
        <p><b>{t.vis}</b> <span className="mut">{t.vis_p}</span></p><br /><p><b>{t.mis}</b> <span className="mut">{t.mis_p}</span></p><Note>{t.ph}</Note></Reveal>
      <Reveal className="frame" label="Placeholder image"><BookOpen size={96} strokeWidth={1.2} /></Reveal>
    </div></section>
  );
}

function Gallery({ t }: { t: Dict }) {
  const [sel, setSel] = useState<number | null>(null);
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setSel(null); };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, []);
  return (
    <section id="gallery" className="alt"><div className="wrap">
      <Heading eyebrow={t.n_gal} title={t.g_h} note={t.g_note} /><br />
      <div className="gal">{[0, 1, 2, 3, 4, 5].map((i) => <button key={i} aria-label={`Open image ${i + 1}`} onClick={() => setSel(i)}><GalleryArt i={i} /></button>)}</div>
    </div>
      {sel !== null && <div id="lb" className="on" role="dialog" aria-modal="true" aria-label="Gallery" onClick={() => setSel(null)}><GalleryArt i={sel} /></div>}
    </section>
  );
}

type Errs = Partial<Record<"name" | "phone" | "program", string>>;
function Admissions({ t, programs }: { t: Dict; programs: string[] }) {
  const [f, setF] = useState({ name: "", phone: "", program: "", message: "" });
  const [err, setErr] = useState<Errs>({});
  const [msg, setMsg] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const digits = f.phone.replace(/[\s\-+]/g, "");
    const er: Errs = {};
    if (!f.name.trim()) er.name = t.e_req;
    if (!PHONE_OK.test(digits)) er.phone = t.e_ph;
    if (!f.program) er.program = t.e_req;
    setErr(er); setMsg("");
    if (Object.keys(er).length) return;
    const sent = await submitInquiry({ kind: "admission", name: f.name.trim(), phone: digits, program: f.program, message: f.message });
    setMsg(sent ? "✓" : t.ok);
  };
  return (
    <section id="admissions"><div className="wrap grid g2" style={{ alignItems: "start" }}>
      <Reveal><div className="eyebrow">{t.n_adm}</div><h2>{t.ad_h}</h2><p className="mut">{t.ad_p}</p><Note>{t.ad_note}</Note></Reveal>
      <form className="card rv in" onSubmit={onSubmit} noValidate>
        <div><label htmlFor="fn">{t.f_name}</label><input id="fn" autoComplete="name" value={f.name} onChange={set("name")} aria-invalid={!!err.name} /><div className="err">{err.name}</div></div>
        <div><label htmlFor="fp">{t.f_ph}</label><input id="fp" type="tel" inputMode="tel" autoComplete="tel" value={f.phone} onChange={set("phone")} aria-invalid={!!err.phone} /><div className="err">{err.phone}</div></div>
        <div><label htmlFor="fg">{t.f_prog}</label><select id="fg" value={f.program} onChange={set("program")} aria-invalid={!!err.program}><option value="">{t.sel}</option>{programs.map((p) => <option key={p}>{p}</option>)}</select><div className="err">{err.program}</div></div>
        <div><label htmlFor="fm">{t.f_msg}</label><textarea id="fm" rows={3} value={f.message} onChange={set("message")} /></div>
        <button className="btn b1" type="submit">{t.f_send}</button>
        {msg && <div className="ok" role="status" style={{ display: "block" }}>{msg}</div>}
      </form>
    </div></section>
  );
}

function Contact({ t }: { t: Dict }) {
  const [name, setName] = useState(""); const [m, setM] = useState(""); const [msg, setMsg] = useState("");
  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const sent = await submitInquiry({ kind: "contact", name: name.trim(), message: m });
    setMsg(sent ? "✓" : t.ok);
  };
  return (
    <section id="contact"><div className="wrap grid g2" style={{ alignItems: "start" }}>
      <Reveal><div className="eyebrow">{t.n_con}</div><h2>{t.c_h}</h2>
        <p><b>Madrassa Aysha Siddiqa Lilbanat Katlang</b><br />{t.addr}</p><br />
        <a className="btn b1" href={WA_URL} target="_blank" rel="noopener noreferrer">{t.wa}</a><br /><br />
        <div className="map">{t.map}</div></Reveal>
      <form className="card rv in" onSubmit={onSubmit} noValidate>
        <div><label htmlFor="cn">{t.f_name}</label><input id="cn" value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div><label htmlFor="cm">{t.f_msg}</label><textarea id="cm" rows={4} value={m} onChange={(e) => setM(e.target.value)} /></div>
        <button className="btn b1" type="submit">{t.f_send}</button>
        {msg && <div className="ok" role="status" style={{ display: "block" }}>{msg}</div>}
      </form>
    </div></section>
  );
}

function Footer({ t }: { t: Dict }) {
  return (
    <footer><div className="wrap grid g3">
      <div><div className="ar" style={{ fontSize: 26 }}>مدرسة عائشة صديقة للبنات كاتلنج</div><div className="serif" style={{ fontSize: 20 }}>Madrassa Aysha Siddiqa Lilbanat Katlang</div><p style={{ opacity: .75, fontSize: 14, marginTop: 8 }}>{t.ft}</p></div>
      <div><h4>{t.ql}</h4>{NAV.slice(0, 5).filter(([id]) => id !== "why").map(([id, k]) => <a key={id} href={`#${id}`}>{t[k]}</a>)}</div>
      <div><h4>{t.n_con}</h4><span style={{ fontSize: 14, opacity: .8 }}>{t.addr}</span><a href="#">Facebook</a><a href="#">YouTube</a><a href={WA_URL} target="_blank" rel="noopener noreferrer">WhatsApp</a></div>
    </div><div className="wrap copy">© 2026 Madrassa Aysha Siddiqa Lilbanat Katlang</div></footer>
  );
}

export default function App() {
  const [lang, setLangState] = useState<Lang>(() => { try { const s = localStorage.getItem("lang"); return s === "ur" || s === "ar" ? s : "en"; } catch { return "en"; } });
  const t = T[lang];
  const programs: string[] = t.P ?? PROGRAMS_EN;
  const setLang = (l: Lang) => { setLangState(l); try { localStorage.setItem("lang", l); } catch { /* storage unavailable */ } };
  useEffect(() => { document.documentElement.lang = lang; document.documentElement.dir = lang === "en" ? "ltr" : "rtl"; }, [lang]);
  return (
    <>
      <Navbar t={t} lang={lang} setLang={setLang} />
      <Hero t={t} /><About t={t} />
      <section id="programs" className="alt"><div className="wrap"><Heading eyebrow={t.n_prog} title={t.pr_h} note={t.pr_note} /><br />
        <div className="grid g3">{programs.map((p, i) => { const I = PROGRAM_ICONS[i]; return <InfoCard key={p} icon={<I size={22} />} title={p} text={t.fd} />; })}</div></div></section>
      <section id="why"><div className="wrap"><Heading eyebrow={t.n_why} title={t.w_h} note={t.w_note} /><br />
        <div className="grid g3">{(t.f as string[]).map((p, i) => { const I = FEATURE_ICONS[i]; return <InfoCard key={p} icon={<I size={22} />} title={p} text={t.fd} />; })}</div></div></section>
      <Gallery t={t} /><Admissions t={t} programs={programs} />
      <section id="principal" className="alt"><div className="wrap grid g2">
        <Reveal className="frame" label="Principal photo placeholder"><span style={{ fontSize: 60 }}>☪</span></Reveal>
        <Reveal><div className="eyebrow">{t.pm_e}</div><h2>{t.pm_h}</h2><p className="serif" style={{ fontSize: 22 }}>{t.pm_p}</p><Note>{t.pm_note}</Note></Reveal></div></section>
      <Contact t={t} /><Footer t={t} />
      <a className="wa" href={WA_URL} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} style={{ verticalAlign: "-3px" }} /> WhatsApp</a>
    </>
  );
}
